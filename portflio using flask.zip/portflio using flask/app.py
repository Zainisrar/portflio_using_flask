from flask import Flask, render_template, request, redirect, url_for, session
import pymongo
import bcrypt
from flask_mail import Mail, Message

app = Flask(__name__)
app.secret_key = 'your_secret_key'

MONGODB_URI = 'mongodb://localhost:27017'
client = pymongo.MongoClient(MONGODB_URI)
db = client['thirty_days_of_python']  


@app.route('/home', methods=["POST","GET"])  # this decorator creates the home route
def home():
    if request.method == "POST":
        print("Ok")
        contact = db.contact  # Use db.users instead of mongo.db.users
        contact.insert_one({"name": request.form["username"], 
                            "phone": request.form["phone"],
                            "email": request.form["email"],
                            "message": request.form["message"]              
                            }) # use insert_one
    return render_template('index.html')

@app.route('/register', methods=["POST","GET"])
def register():
    if request.method == "POST":
        # print("Ok")
        users = db.users  # Use db.users instead of mongo.db.users
        register_user = users.find_one({'name': request.form["Username"]})
        if register_user is None:
            hashpass = bcrypt.hashpw(request.form["Password"].encode("utf-8"), bcrypt.gensalt())
            users.insert_one({"name": request.form["Username"], "password": hashpass}) # use insert_one
            session["username"] = request.form["Username"]
            return redirect(url_for("login"))  # Redirect to home instead of index
        return "User already exists"
    return render_template("register.html")
@app.route('/')
@app.route('/login', methods=["POST", "GET"])
def login():
    if request.method == "POST":
        users = db.users
        login_user = users.find_one({'name': request.form.get("Username")})

        if login_user:
            if bcrypt.checkpw(request.form.get("Password").encode("utf-8"), login_user["password"]):
                session["username"] = request.form.get("Username")
                return redirect(url_for("home"))
            else:
                s="Invalid password"
                return render_template('login.html',s)
        else:
            s="Invalid Username"
            return render_template('login.html',s=s)
    else:
        # Handle GET request, such as rendering a login form
        return render_template('login.html')


if __name__ == '__main__':
    app.run(debug=True)